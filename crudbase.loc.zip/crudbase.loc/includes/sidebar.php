<nav class="col-md-2 d-none d-md-block bg-light sidebar">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="form.php">
                    <span data-feather="plus-circle"></span>
                    Add New
                </a>
            </li>
        </ul>
    </div>
</nav>